// RNK Dedpewl™ - Pool Data Manager
// © 2026 RNK Enterprises. All rights reserved.
// Data persistence and state management utilities

export class PoolData {
    constructor() {
        this.cache = new Map();
        this.listeners = new Map();
    }

    /**
     * Get pools data from settings with caching
     * @returns {Object} Pools data
     */
    getPoolsData() {
        if (this.cache.has('pools')) {
            return this.cache.get('pools');
        }

        const data = game.settings.get('rnk-dedpewl', 'pools') || {};
        this.cache.set('pools', data);
        return data;
    }

    /**
     * Save pools data to settings and update cache
     * @param {Object} data - Pools data to save
     */
    async setPoolsData(data) {
        await game.settings.set('rnk-dedpewl', 'pools', data);
        this.cache.set('pools', data);
        this._triggerEvent('dataSaved', { data });
    }

    /**
     * Clear cache for specific key
     * @param {string} key - Cache key
     */
    clearCache(key = 'pools') {
        this.cache.delete(key);
        this._triggerEvent('cacheCleared', { key });
    }

    /**
     * Export pools data for backup
     * @returns {string} JSON string of pools data
     */
    exportData() {
        const data = this.getPoolsData();
        return JSON.stringify(data, null, 2);
    }

    /**
     * Import pools data from backup
     * @param {string} jsonData - JSON string of pools data
     * @returns {boolean} Success
     */
    async importData(jsonData) {
        try {
            const data = JSON.parse(jsonData);
            // Validate data structure
            if (typeof data !== 'object') throw new Error('Invalid data format');

            await this.setPoolsData(data);
            this._triggerEvent('dataImported', { data });
            return true;
        } catch (error) {
            console.error('RNK Dedpewl™ | Import error:', error);
            return false;
        }
    }

    /**
     * Get statistics for pools
     * @returns {Object} Statistics data
     */
    getStatistics() {
        const data = this.getPoolsData();
        const stats = {
            totalPools: Object.keys(data).length,
            totalDice: 0,
            averageDicePerPool: 0,
            poolsWithAutoRoll: 0,
            poolsWithNotifications: 0
        };

        Object.values(data).forEach(pool => {
            stats.totalDice += pool.dice ? pool.dice.length : 0;
            if (pool.autoRoll) stats.poolsWithAutoRoll++;
            if (pool.chatNotifications) stats.poolsWithNotifications++;
        });

        if (stats.totalPools > 0) {
            stats.averageDicePerPool = stats.totalDice / stats.totalPools;
        }

        return stats;
    }

    /**
     * Validate pool data structure
     * @param {Object} poolData - Pool data to validate
     * @returns {boolean} Is valid
     */
    validatePoolData(poolData) {
        if (!poolData || typeof poolData !== 'object') return false;
        if (!poolData.id || typeof poolData.id !== 'string') return false;
        if (!poolData.name || typeof poolData.name !== 'string') return false;
        if (!Array.isArray(poolData.dice)) return false;
        if (typeof poolData.maxDice !== 'number' || poolData.maxDice < 1) return false;

        return true;
    }

    /**
     * Migrate old data format if needed
     * @param {Object} oldData - Old format data
     * @returns {Object} Migrated data
     */
    migrateData(oldData) {
        // Future-proofing for data migrations
        // Currently no migrations needed, but structure is ready
        return oldData;
    }

    /**
     * Register event listener
     * @param {string} event - Event name
     * @param {Function} callback - Callback function
     */
    on(event, callback) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, []);
        }
        this.listeners.get(event).push(callback);
    }

    /**
     * Unregister event listener
     * @param {string} event - Event name
     * @param {Function} callback - Callback function
     */
    off(event, callback) {
        const listeners = this.listeners.get(event);
        if (listeners) {
            const index = listeners.indexOf(callback);
            if (index > -1) {
                listeners.splice(index, 1);
            }
        }
    }

    /**
     * Trigger event to listeners
     * @param {string} event - Event name
     * @param {Object} data - Event data
     */
    _triggerEvent(event, data) {
        const listeners = this.listeners.get(event);
        if (listeners) {
            listeners.forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error('RNK Dedpewl™ | PoolData event listener error:', error);
                }
            });
        }
    }
}