// RNK Dedpewl™ - Automation Hooks
// © 2026 RNK Enterprises. All rights reserved.
// Trigger macros and actions on pool events

import { ErrorHandler } from './ErrorHandler.js';

export class AutomationHooks {
    /**
     * Hook trigger types
     */
    static TRIGGER_TYPES = {
        POOL_CREATED: 'poolCreated',
        POOL_DELETED: 'poolDeleted',
        DIE_ADDED: 'dieAdded',
        COMPLICATION_THRESHOLD: 'complicationThreshold',
        POOL_ROLLED: 'poolRolled'
    };

    /**
     * Create a new automation hook
     * @param {string} trigger - Trigger type
     * @param {Object} config - Hook configuration
     * @returns {string} Hook ID
     */
    static createHook(trigger, config = {}) {
        try {
            if (!Object.values(this.TRIGGER_TYPES).includes(trigger)) {
                throw new Error(`Invalid trigger type: ${trigger}`);
            }

            const hooks = this._loadHooks();
            const id = `hook_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

            hooks[id] = {
                id,
                trigger,
                enabled: true,
                config,
                createdAt: Date.now()
            };

            this._saveHooks(hooks);
            return id;
        } catch (error) {
            ErrorHandler.handle('AutomationHooks.createHook', error);
            return null;
        }
    }

    /**
     * Get all hooks for a trigger
     * @param {string} trigger - Trigger type
     * @returns {Array} Array of hooks
     */
    static getHooksForTrigger(trigger) {
        try {
            const hooks = this._loadHooks();
            return Object.values(hooks)
                .filter(h => h.trigger === trigger && h.enabled)
                .sort((a, b) => a.createdAt - b.createdAt);
        } catch (error) {
            ErrorHandler.handle('AutomationHooks.getHooksForTrigger', error);
            return [];
        }
    }

    /**
     * Execute hooks for a trigger
     * @param {string} trigger - Trigger type
     * @param {Object} data - Event data
     * @returns {Promise<void>}
     */
    static async executeTrigger(trigger, data) {
        try {
            const hooks = this.getHooksForTrigger(trigger);

            for (const hook of hooks) {
                await this._executeHook(hook, data);
            }
        } catch (error) {
            ErrorHandler.handle('AutomationHooks.executeTrigger', error, { showUser: false });
        }
    }

    /**
     * Execute a single hook
     * @private
     */
    static async _executeHook(hook, data) {
        try {
            switch (hook.config.type) {
                case 'macro':
                    if (hook.config.macroId) {
                        const macro = game.macros.get(hook.config.macroId);
                        if (macro) {
                            // Create custom context with pool data
                            const context = { poolData: data };
                            await macro.execute(context);
                        }
                    }
                    break;

                case 'chat':
                    if (hook.config.messageTemplate) {
                        const message = this._formatMessage(hook.config.messageTemplate, data);
                        await ChatMessage.create({
                            content: message,
                            speaker: { alias: 'RNK Dedpewl™ - Automation' }
                        });
                    }
                    break;

                case 'customScript':
                    if (hook.config.script) {
                        // Execute custom script in controlled sandbox
                        new Function('data', `"use strict"; ${hook.config.script}`)(data);
                    }
                    break;
            }
        } catch (error) {
            console.error(`RNK Dedpewl | Failed to execute hook ${hook.id}:`, error);
        }
    }

    /**
     * Format message template with data
     * @private
     */
    static _formatMessage(template, data) {
        let message = template;
        Object.entries(data).forEach(([key, value]) => {
            message = message.replace(`{{${key}}}`, value);
        });
        return message;
    }

    /**
     * Delete a hook
     * @param {string} hookId - Hook ID
     */
    static deleteHook(hookId) {
        try {
            const hooks = this._loadHooks();
            delete hooks[hookId];
            this._saveHooks(hooks);
        } catch (error) {
            ErrorHandler.handle('AutomationHooks.deleteHook', error);
        }
    }

    /**
     * Toggle hook enabled state
     * @param {string} hookId - Hook ID
     * @param {boolean} enabled - Enabled state
     */
    static setHookEnabled(hookId, enabled) {
        try {
            const hooks = this._loadHooks();
            if (hooks[hookId]) {
                hooks[hookId].enabled = enabled;
                this._saveHooks(hooks);
            }
        } catch (error) {
            ErrorHandler.handle('AutomationHooks.setHookEnabled', error);
        }
    }

    /**
     * Load hooks from settings
     * @private
     */
    static _loadHooks() {
        return game.settings.get('rnk-dedpewl', 'automationHooks') || {};
    }

    /**
     * Save hooks to settings
     * @private
     */
    static _saveHooks(hooks) {
        game.settings.set('rnk-dedpewl', 'automationHooks', hooks);
    }
}
