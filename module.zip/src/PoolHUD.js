// RNK Dedpewl™ - Pool HUD
// © 2026 RNK Enterprises. All rights reserved.

const { HandlebarsApplicationMixin, ApplicationV2 } = foundry.applications.api; 

export class PoolHUD extends HandlebarsApplicationMixin(ApplicationV2) {
    static DEFAULT_OPTIONS = {
        id: "rnk-dedpewl-hud",
        classes: ["rnk-dedpewl", "rnk-hud"],
        tag: "div",
        window: {
            frame: false,
            positioned: true
        },
        position: {
            width: 250,
            height: "auto",
            top: 200,
            left: 200
        },
        actions: {
            addDie: PoolHUD.addDie,
            rollPool: PoolHUD.rollPool
        }
    };

    static PARTS = {
        main: {
            template: "modules/rnk-dedpewl/templates/hud.hbs"
        }
    };

    constructor(options = {}) {
        super(options);
        this._handlePoolUpdate = this._onPoolUpdate.bind(this);
        Hooks.on('rnk-dedpewl-pool-updated', this._handlePoolUpdate);
    }

    async _onPoolUpdate(data) {
        if (this._renderTimeout) clearTimeout(this._renderTimeout);
        this._renderTimeout = setTimeout(async () => {
            if (this.rendered) {
                await this.render(true);
            }
            this._renderTimeout = null;
        }, 100);
    }

    /** @override */
    _onClose(options) {
        super._onClose(options);
        Hooks.off('rnk-dedpewl-pool-updated', this._handlePoolUpdate);
    }

    /** @override */
    async _prepareContext(options) {
        const context = await super._prepareContext(options);
        const api = game.modules.get('rnk-dedpewl').api;
        const pools = api ? await api.getAllPools() : [];

        return {
            ...context,
            isGM: game.user.isGM,
            pools: pools.map(pool => {
                const diceLength = Array.isArray(pool.dice) ? pool.dice.length : 0;
                const maxDice = parseInt(pool.maxDice) || 6;
                return {
                    ...pool,
                    diceLength,
                    maxDice,
                    isFull: diceLength >= maxDice,
                    percentage: Math.min((diceLength / maxDice) * 100, 100)
                };
            })
        };
    }

    /** @override */
    _onRender(context, options) {
        super._onRender(context, options);
        
        // Setup Dragging
        const handle = this.element.querySelector('.hud-drag-handle');
        if (handle) {
            handle.addEventListener('pointerdown', this._onDragStart.bind(this));
        }
        
        this.element.style.pointerEvents = "auto";
    }

    _onDragStart(event) {
        event.preventDefault();
        event.stopPropagation();
        
        this._dragStartX = event.clientX;
        this._dragStartY = event.clientY;
        this._initialLeft = this.position.left;
        this._initialTop = this.position.top;
        
        this._onDragMoveBound = this._onDragMove.bind(this);
        this._onDragEndBound = this._onDragEnd.bind(this);
        
        document.addEventListener('pointermove', this._onDragMoveBound);
        document.addEventListener('pointerup', this._onDragEndBound);
    }

    _onDragMove(event) {
        event.preventDefault();
        event.stopPropagation();
        
        const dx = event.clientX - this._dragStartX;
        const dy = event.clientY - this._dragStartY;
        
        // Use ApplicationV2 setPosition method
        this.setPosition({
            left: this._initialLeft + dx,
            top: this._initialTop + dy
        });
    }

    _onDragEnd(event) {
        document.removeEventListener('pointermove', this._onDragMoveBound);
        document.removeEventListener('pointerup', this._onDragEndBound);
        
        // Save position to user flags
        game.user.setFlag('rnk-dedpewl', 'hudPosition', { 
            left: this.position.left, 
            top: this.position.top 
        });
    }

    /** @override */
    _onFirstRender(context, options) {
        super._onFirstRender(context, options);
        const savedPos = game.user.getFlag('rnk-dedpewl', 'hudPosition');
        if (savedPos) {
            this.setPosition({ left: savedPos.left, top: savedPos.top });
        }
    }
    static async addDie(event, target) {
        const poolId = target.dataset.poolId;
        const api = game.modules.get('rnk-dedpewl').api;
        if (api) await api.addDie(poolId);
    }
    static async rollPool(event, target) {
        const poolId = target.dataset.poolId;
        const api = game.modules.get('rnk-dedpewl').api;
        if (api) await api.rollPool(poolId);
    }
}
