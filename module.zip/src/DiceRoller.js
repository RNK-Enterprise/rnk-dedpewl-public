// RNK Dedpewl™ - Dice Roller
// © 2026 RNK Enterprises. All rights reserved.
// Rolling mechanics with trigger-based events and Foundry integration

export class DiceRoller {
    constructor() {
        this.listeners = new Map();
    }

    /**
     * Roll a tension pool
     * @param {Object} pool - Pool object with dice array
     * @returns {Promise<Object>} Roll results
     */
    async rollPool(pool) {
        if (!pool || !pool.dice || pool.dice.length === 0) {
            throw new Error('Invalid pool or empty dice array');
        }

        const diceCount = pool.dice.length;
        const formula = `${diceCount}d6`;

        // Use Foundry's roll system
        const roll = await new Roll(formula).evaluate();

        const results = {
            poolId: pool.id,
            poolName: pool.name,
            diceCount,
            formula,
            total: roll.total,
            dice: roll.dice[0].results.map((result, index) => ({
                dieId: pool.dice[index]?.id || `unknown-${index}`,
                userId: pool.dice[index]?.userId || 'unknown',
                value: result.result,
                success: result.result >= 4 // Tension pool success threshold
            })),
            successes: roll.dice[0].results.filter(r => r.result >= 4).length,
            complications: roll.dice[0].results.filter(r => r.result === 1).length,
            timestamp: Date.now()
        };

        this._triggerEvent('poolRolled', results);

        // Record analytics
        try {
            const { PoolAnalytics } = await import('./PoolAnalytics.js');
            PoolAnalytics.recordRoll(results);
        } catch (error) {
            console.error('RNK Dedpewl | Failed to record analytics:', error);
        }

        // Send chat notification if enabled
        if (pool.chatNotifications) {
            await this._sendChatNotification(results);
        }

        return results;
    }

    /**
     * Roll a single die for testing
     * @param {number} sides - Number of sides (default 6)
     * @returns {Promise<number>} Die result
     */
    async rollDie(sides = 6) {
        const roll = await new Roll(`1d${sides}`).evaluate();
        const result = roll.total;

        this._triggerEvent('dieRolled', { sides, result });

        return result;
    }

    /**
     * Calculate complication likelihood
     * @param {number} diceCount - Number of dice
     * @returns {Object} Likelihood data
     */
    calculateComplicationLikelihood(diceCount) {
        // Based on Angry GM's complication tables
        const likelihoods = {
            1: 25.0,
            2: 21.9,
            3: 19.3,
            4: 17.1,
            5: 15.3,
            6: 13.7,
            7: 12.4,
            8: 11.2,
            9: 10.3,
            10: 9.4
        };

        return {
            diceCount,
            likelihood: likelihoods[diceCount] || 0,
            expectedComplications: (likelihoods[diceCount] || 0) / 100 * diceCount
        };
    }

    /**
     * Send chat notification for roll results
     * @param {Object} results - Roll results
     */
    async _sendChatNotification(results) {
        const successText = results.successes > 0 ?
            `<span style="color: #39ff14; font-weight: bold;">${results.successes} successes</span>` :
            '<span style="color: #666;">No successes</span>';

        const complicationText = results.complications > 0 ?
            `<span style="color: #ff6b6b; font-weight: bold;">${results.complications} complications</span>` :
            '<span style="color: #666;">No complications</span>';

        const diceDetails = results.dice.map(die => {
            let color = '#666'; // Default gray
            if (die.success) color = '#39ff14'; // Green for success
            if (die.value === 1) color = '#ff6b6b'; // Red for complication
            return `<span style="color: ${color}; font-weight: bold; margin: 0 2px;">${die.value}</span>`;
        }).join('');

        const content = `
            <div class="rnk-dedpewl-chat">
                <h3>🎲 ${results.poolName} Tension Roll</h3>
                <div style="display: flex; justify-content: space-between; margin: 10px 0;">
                    <span><strong>Total:</strong> ${results.total}</span>
                    <span><strong>Dice:</strong> ${results.diceCount}</span>
                </div>
                <div style="margin: 10px 0;">
                    <strong>Results:</strong> ${diceDetails}
                </div>
                <div style="display: flex; justify-content: space-between; margin: 10px 0;">
                    <span>${successText}</span>
                    <span>${complicationText}</span>
                </div>
                <div style="font-size: 0.9em; color: #666; margin-top: 10px; border-top: 1px solid #333; padding-top: 5px;">
                    <em>RNK Dedpewl™ - Crimson Blood Tension Pool</em>
                </div>
            </div>
        `;

        await ChatMessage.create({
            user: game.user.id,
            content,
            type: CONST.CHAT_MESSAGE_TYPES.ROLL,
            speaker: {
                alias: 'RNK Dedpewl™'
            },
            roll: await new Roll(`${results.diceCount}d6`).evaluate()
        });
    }

    /**
     * Register event listener
     * @param {string} event - Event name
     * @param {Function} callback - Callback function
     */
    on(event, callback) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, []);
        }
        this.listeners.get(event).push(callback);
    }

    /**
     * Unregister event listener
     * @param {string} event - Event name
     * @param {Function} callback - Callback function
     */
    off(event, callback) {
        const listeners = this.listeners.get(event);
        if (listeners) {
            const index = listeners.indexOf(callback);
            if (index > -1) {
                listeners.splice(index, 1);
            }
        }
    }

    /**
     * Trigger event to listeners
     * @param {string} event - Event name
     * @param {Object} data - Event data
     */
    _triggerEvent(event, data) {
        const listeners = this.listeners.get(event);
        if (listeners) {
            listeners.forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error('RNK Dedpewl™ | DiceRoller event listener error:', error);
                }
            });
        }
    }
}