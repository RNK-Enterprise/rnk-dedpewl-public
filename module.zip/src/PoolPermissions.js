// RNK Dedpewl™ - Multi-User Permissions
// © 2026 RNK Enterprises. All rights reserved.
// Control who can add/remove dice from pools

export class PoolPermissions {
    /**
     * Permission levels for pools
     */
    static PERMISSION_LEVELS = {
        PRIVATE: 'private',      // GM only
        TRUSTED: 'trusted',      // GM + trusted users
        PUBLIC: 'public'         // All players
    };

    /**
     * Initialize permissions for a pool
     * @param {string} poolId - Pool ID
     * @param {string} level - Permission level (private, trusted, public)
     * @param {Array<string>} trustedUserIds - IDs of trusted users (for TRUSTED level)
     */
    static initializePool(poolId, level = 'private', trustedUserIds = []) {
        const permissions = this._loadPermissions();
        permissions[poolId] = {
            level,
            trustedUserIds: trustedUserIds || [],
            createdAt: Date.now()
        };
        this._savePermissions(permissions);
    }

    /**
     * Check if user can add die to pool
     * @param {string} poolId - Pool ID
     * @param {string} userId - User ID to check
     * @returns {boolean} Can user add die
     */
    static canAddDie(poolId, userId = null) {
        userId = userId || game.user.id;

        // GM can always add dice
        if (game.user.isGM) return true;

        const permissions = this._loadPermissions();
        const poolPerms = permissions[poolId] || { level: 'private' };

        switch (poolPerms.level) {
            case 'public':
                return true;
            case 'trusted':
                return poolPerms.trustedUserIds.includes(userId);
            case 'private':
            default:
                return false;
        }
    }

    /**
     * Check if user can remove die from pool
     * @param {string} poolId - Pool ID
     * @param {string} userId - User ID to check
     * @returns {boolean} Can user remove die
     */
    static canRemoveDie(poolId, userId = null) {
        userId = userId || game.user.id;

        // Only GM can remove dice
        return game.user.isGM;
    }

    /**
     * Set pool permission level
     * @param {string} poolId - Pool ID
     * @param {string} level - Permission level
     * @param {Array<string>} trustedUserIds - Trusted user IDs
     */
    static setPermissionLevel(poolId, level, trustedUserIds = []) {
        if (!Object.values(this.PERMISSION_LEVELS).includes(level)) {
            console.error('Invalid permission level:', level);
            return;
        }

        const permissions = this._loadPermissions();
        permissions[poolId] = {
            level,
            trustedUserIds: level === 'trusted' ? trustedUserIds : [],
            createdAt: permissions[poolId]?.createdAt || Date.now()
        };
        this._savePermissions(permissions);
    }

    /**
     * Get permission level for pool
     * @param {string} poolId - Pool ID
     * @returns {Object} Permission data
     */
    static getPermissionLevel(poolId) {
        const permissions = this._loadPermissions();
        return permissions[poolId] || { level: 'private', trustedUserIds: [] };
    }

    /**
     * Load permissions from settings
     * @private
     */
    static _loadPermissions() {
        return game.settings.get('rnk-dedpewl', 'poolPermissions') || {};
    }

    /**
     * Save permissions to settings
     * @private
     */
    static _savePermissions(permissions) {
        game.settings.set('rnk-dedpewl', 'poolPermissions', permissions);
    }
}
