// RNK Dedpewl™ - Edit Pool Window
// © 2026 RNK Enterprises. All rights reserved.

const { HandlebarsApplicationMixin, ApplicationV2 } = foundry.applications.api;

export class EditPoolWindow extends HandlebarsApplicationMixin(ApplicationV2) {
    constructor(data = {}) {
        super(data);
        this.pool = data.pool || {};
    }

    static DEFAULT_OPTIONS = {
        classes: ["rnk-dedpewl", "rnk-window"],
        window: {
            frame: true,
            title: "RNK_DEDPEWL.EditPool",
            icon: "fas fa-edit",
            resizable: false,
            minimizable: true
        },
        position: {
            width: 400,
            height: "auto"
        }
    };

    /** Override to set dynamic ID based on pool */
    _prepareFinalOptions(options) {
        const finalOptions = super._prepareFinalOptions(options);
        finalOptions.id = `rnk-dedpewl-edit-pool-${this.pool?.id || 'new'}`;
        return finalOptions;
    }

    static PARTS = {
        main: {
            template: "modules/rnk-dedpewl/templates/edit-pool.hbs"
        }
    };

    async _prepareContext(options) {
        const context = await super._prepareContext(options);
        return {
            ...context,
            pool: this.pool
        };
    }

    async _onClickAction(event, target) {
        const action = target.dataset.action;
        if (action === 'save') {
            await this.onSavePool(event);
        } else if (action === 'cancel') {
            this.close();
        } else {
            super._onClickAction(event, target);
        }
    }

    async onSavePool(event) {
        try {
            const form = this.element.querySelector('form');
            if (!form) return;

            const formData = new FormData(form);
            const updates = {
                name: formData.get('name')?.trim() || this.pool.name,
                maxDice: parseInt(formData.get('maxDice')) || this.pool.maxDice,
                autoRoll: formData.get('autoRoll') === 'on',
                chatNotifications: formData.get('chatNotifications') === 'on'
            };

            const api = game.modules.get('rnk-dedpewl').api;
            await api.updatePool(this.pool.id, updates);
            
            ui.notifications.info(game.i18n.localize('RNK_DEDPEWL.PoolUpdated'));
            
            // Refresh the main pool window
            const mainWindow = foundry.applications.instances.get('rnk-dedpewl-pool-window');
            if (mainWindow) await mainWindow.render();
            
            this.close();
        } catch (err) {
            console.error('RNK Dedpewl | onSavePool error:', err);
            ui.notifications.error('Failed to update pool');
        }
    }
}
