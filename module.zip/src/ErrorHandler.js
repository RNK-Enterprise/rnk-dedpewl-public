// RNK Dedpewl™ - Error Handler
// © 2026 RNK Enterprises. All rights reserved.
// Centralized error handling and user notifications

/**
 * Centralized error handler for consistent error management
 */
export class ErrorHandler {
    /**
     * Handle an error with user notification
     * @param {string} context - Where the error occurred
     * @param {Error} error - The error object
     * @param {Object} options - Options for error handling
     * @param {boolean} options.showUser - Show error to user (default: true)
     * @param {boolean} options.log - Log error to console (default: true)
     */
    static handle(context, error, options = {}) {
        const { showUser = true, log = true } = options;

        if (log) {
            console.error(`RNK Dedpewl | ${context}:`, error);
        }

        if (showUser && ui?.notifications) {
            const message = error?.message || 'An unknown error occurred';
            ui.notifications.error(`${context}: ${message}`);
        }
    }

    /**
     * Validate required data
     * @param {Object} data - Data to validate
     * @param {Array<string>} required - Required fields
     * @throws {Error} If required fields are missing
     */
    static validateRequired(data, required) {
        for (const field of required) {
            if (!(field in data) || data[field] === undefined || data[field] === null) {
                throw new Error(`Missing required field: ${field}`);
            }
        }
    }

    /**
     * Validate pool data structure
     * @param {Object} pool - Pool object
     * @throws {Error} If pool is invalid
     */
    static validatePool(pool) {
        this.validateRequired(pool, ['id', 'name', 'dice', 'maxDice']);

        if (!Array.isArray(pool.dice)) {
            throw new Error('Pool dice must be an array');
        }

        if (typeof pool.maxDice !== 'number' || pool.maxDice < 1) {
            throw new Error('Pool maxDice must be a positive number');
        }

        if (pool.dice.length > pool.maxDice) {
            throw new Error(`Pool has more dice (${pool.dice.length}) than maxDice (${pool.maxDice})`);
        }
    }

    /**
     * Safe async execution wrapper
     * @param {string} context - Operation context
     * @param {Function} fn - Async function to execute
     * @returns {Promise<any>} Result or null on error
     */
    static async safeAsync(context, fn) {
        try {
            return await fn();
        } catch (error) {
            this.handle(context, error);
            return null;
        }
    }
}
