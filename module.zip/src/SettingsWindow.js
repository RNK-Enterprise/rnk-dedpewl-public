// RNK Dedpewl™ - Settings Window
// © 2026 RNK Enterprises. All rights reserved.
// Configuration interface for RNK Dedpewl settings using Foundry v13 ApplicationV2

const { HandlebarsApplicationMixin, ApplicationV2 } = foundry.applications.api;

export class SettingsWindow extends HandlebarsApplicationMixin(ApplicationV2) {
    static DEFAULT_OPTIONS = {
        id: "rnk-dedpewl-settings-window",
        classes: ["rnk-dedpewl", "rnk-window"],
        window: {
            title: "RNK_DEDPEWL.SettingsTitle",
            frame: true,
            icon: "fas fa-cog",
            resizable: false,
            minimizable: true
        },
        position: {
            width: 500,
            height: "auto"
        }
    };

    static PARTS = {
        main: {
            template: "modules/rnk-dedpewl/templates/settings.hbs"
        }
    };

    /**
     * Prepare context data for the template
     */
    async _prepareContext(options) {
        const context = await super._prepareContext(options);
        
        return {
            ...context,
            settings: {
                defaultMaxDice: game.settings.get('rnk-dedpewl', 'defaultMaxDice') || 6,
                safeRolls: game.settings.get('rnk-dedpewl', 'safeRolls') || false,
                showRollMessages: game.settings.get('rnk-dedpewl', 'showRollMessages') || true,
                playRollSound: game.settings.get('rnk-dedpewl', 'playRollSound') || true
            }
        };
    }

    /**
     * Handle action clicks
     */
    async _onClickAction(event, target) {
        const action = target.dataset.action;
        if (action === 'save') {
            await this.onSaveSettings(event);
        } else {
            super._onClickAction(event, target);
        }
    }

    /**
     * Handle settings save
     */
    async onSaveSettings(event) {
        try {
            const form = this.element.querySelector('form');
            if (!form) return;

            const formData = new FormData(form);
            
            await game.settings.set('rnk-dedpewl', 'defaultMaxDice', parseInt(formData.get('defaultMaxDice')) || 6);
            await game.settings.set('rnk-dedpewl', 'safeRolls', formData.get('safeRolls') === 'on');
            await game.settings.set('rnk-dedpewl', 'showRollMessages', formData.get('showRollMessages') === 'on');
            await game.settings.set('rnk-dedpewl', 'playRollSound', formData.get('playRollSound') === 'on');
            
            ui.notifications.info(game.i18n.localize('RNK_DEDPEWL.SettingsSaved'));
            this.close();
        } catch (err) {
            console.error('RNK Dedpewl | onSaveSettings error:', err);
            ui.notifications.error('Failed to save settings');
        }
    }
}
