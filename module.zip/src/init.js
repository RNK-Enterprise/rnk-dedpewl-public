// RNK Dedpewl™ - Advanced Tension Pool Module
// © 2026 RNK Enterprises. All rights reserved.

import { getAPI } from './API.js';

Hooks.once('init', () => {
    // Register settings used in the templates
    game.settings.register('rnk-dedpewl', 'defaultMaxDice', {
        name: 'RNK_DEDPEWL.DefaultMaxDice',
        hint: 'RNK_DEDPEWL.DefaultMaxDiceHint',
        scope: 'world',
        config: false,
        type: Number,
        default: 6
    });

    game.settings.register('rnk-dedpewl', 'safeRolls', {
        name: 'RNK_DEDPEWL.SafeRolls',
        hint: 'RNK_DEDPEWL.SafeRollsHint',
        scope: 'world',
        config: false,
        type: Boolean,
        default: false
    });

    game.settings.register('rnk-dedpewl', 'showRollMessages', {
        name: 'RNK_DEDPEWL.ShowRollMessages',
        scope: 'world',
        config: false,
        type: Boolean,
        default: true
    });

    game.settings.register('rnk-dedpewl', 'playRollSound', {
        name: 'RNK_DEDPEWL.PlayRollSound',
        scope: 'client',
        config: false,
        type: Boolean,
        default: true
    });

    // Module internal settings
    game.settings.register('rnk-dedpewl', 'pools', {
        scope: 'world',
        config: false,
        type: Object,
        default: {}
    });

    game.settings.register('rnk-dedpewl', 'poolTemplates', {
        scope: 'world',
        config: false,
        type: Object,
        default: {}
    });

    game.settings.register('rnk-dedpewl', 'poolPermissions', {
        scope: 'world',
        config: false,
        type: Object,
        default: {}
    });

    game.settings.register('rnk-dedpewl', 'automationHooks', {
        scope: 'world',
        config: false,
        type: Object,
        default: {}
    });

    game.settings.register('rnk-dedpewl', 'poolAnalytics', {
        scope: 'world',
        config: false,
        type: Object,
        default: {}
    });

    game.settings.register('rnk-dedpewl', 'showSceneButton', {
        scope: 'client',
        config: false,
        type: Boolean,
        default: true
    });

    // Register API
    game.modules.get('rnk-dedpewl').api = getAPI();
});

Hooks.on('getSceneControlButtons', (controls) => {
    if (!game.settings.get('rnk-dedpewl', 'showSceneButton')) return;

    const toolId = 'rnk-dedpewl-open';
    const tool = {
        name: toolId,
        title: 'RNK_DEDPEWL.WindowTitle',
        icon: 'fas fa-tint',
        button: true,
        toggle: false,
        onChange: (active) => {
            if (!active) return;

            (async () => {
                try {
                    const { PoolWindow } = await import('./PoolWindow.js');
                    const app = foundry.applications.instances.get("rnk-dedpewl-pool-window");
                    if (app) {
                        app.render(true, {focus: true});
                    } else {
                        const window = new PoolWindow();
                        await window.render(true);
                    }
                } catch (err) {
                    console.error("RNK Dedpewl | Failed to open GM Hub:", err);
                    if (ui) ui.notifications.error("Failed to open RNK Dedpewl GM Hub: " + err.message);
                }
            })();
        }
    };

    const control = {
        name: 'rnk-dedpewl',
        title: 'RNK_DEDPEWL.WindowTitle',
        icon: 'fas fa-skull-crossbones',
        order: 100,
        layer: 'tokens',
        visible: true,
        tools: Array.isArray(controls) ? [tool] : { [toolId]: tool }
    };

    if (Array.isArray(controls)) {
        controls.push(control);
    } else if (controls && typeof controls === 'object') {
        controls['rnk-dedpewl'] = control;
    }
});

// Also add a simple global command for testing
Hooks.once('ready', () => {
    window.RNKDedpewlOpen = async () => {
        try {
            const { PoolWindow } = await import('./PoolWindow.js');
            const app = foundry.applications.instances.get("rnk-dedpewl-pool-window");
            if (app) app.render(true, {focus: true});
            else new PoolWindow().render(true);
        } catch (err) {
            console.error("RNK Dedpewl | Error:", err);
        }
    };
});

Hooks.once('ready', () => {
    console.log("RNK Dedpewl | Ready Hook Fired! Checking for GM...");
    if (game.user.isGM) {
        console.log("RNK Dedpewl | Is GM. Importing PoolHUD...");
        import('./PoolHUD.js').then(({ PoolHUD }) => {
            console.log("RNK Dedpewl | PoolHUD imported successfully.");
            const api = game.modules.get('rnk-dedpewl').api;
            
            if (!game.modules.get('rnk-dedpewl').hud) {
                console.log("RNK Dedpewl | Initializing and rendering HUD...");
                const hud = new PoolHUD();
                game.modules.get('rnk-dedpewl').hud = hud;
                hud.render(true);

                const updateHUD = () => {
                    if (hud.rendered) {
                        hud.render(true);
                    }
                };

                // Catch API events
                try {
                    api.on('poolCreated', updateHUD);
                    api.on('poolDeleted', updateHUD);
                    api.on('dieAdded', updateHUD);
                    api.on('dieRemoved', updateHUD);
                    api.on('poolCleared', updateHUD);
                    api.on('poolRolled', updateHUD);
                } catch(e) {
                    console.error("RNK Dedpewl | Failed to attach API events:", e);
                }
            }
        }).catch(err => {
            console.error("RNK Dedpewl | Failed to load Pool HUD via dynamic import:", err);
        });
    }
});
