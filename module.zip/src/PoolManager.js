// RNK Dedpewl™ - Pool Manager
// © 2026 RNK Enterprises. All rights reserved.
// Core logic for managing multiple tension pools with lazy loading and trigger-based events

export class PoolManager {
    constructor() {
        this.pools = new Map();
        this.listeners = new Map();
        this._initialized = false;
    }

    /**
     * Lazy initialization - called when first pool is accessed
     */
    _ensureInitialized() {
        if (this._initialized) return;

        // Load existing pools from settings
        const savedPools = game.settings.get('rnk-dedpewl', 'pools') || {};
        Object.entries(savedPools).forEach(([id, data]) => {
            this.pools.set(id, {
                id,
                name: data.name || `Pool ${id}`,
                dice: data.dice || [],
                maxDice: data.maxDice || 10,
                autoRoll: data.autoRoll || false,
                chatNotifications: data.chatNotifications || true,
                ...data
            });
        });

        this._initialized = true;
    }

    /**
     * Create a new tension pool
     * @param {string} name - Pool name
     * @param {number} maxDice - Maximum dice capacity
     * @param {boolean} autoRoll - Auto roll when full
     * @param {boolean} chatNotifications - Enable chat notifications
     * @returns {string} Pool ID
     */
    createPool(name, maxDice = 10, autoRoll = false, chatNotifications = true) {
        this._ensureInitialized();

        const id = `pool_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const pool = {
            id,
            name,
            dice: [],
            maxDice,
            autoRoll,
            chatNotifications
        };

        this.pools.set(id, pool);
        this._savePools();
        this._triggerEvent('poolCreated', { pool });
        Hooks.callAll('rnk-dedpewl-pool-updated', { pool });

        return id;
    }

    /**
     * Delete a pool
     * @param {string} poolId - Pool ID to delete
     */
    deletePool(poolId) {
        if (!this.pools.has(poolId)) return;

        const pool = this.pools.get(poolId);
        this.pools.delete(poolId);
        this._savePools();
        this._triggerEvent('poolDeleted', { poolId, pool });
        Hooks.callAll('rnk-dedpewl-pool-updated', { poolId, pool });
    }

    /**
     * Update pool properties
     * @param {string} poolId - Pool ID
     * @param {Object} updates - Properties to update (name, maxDice, autoRoll, chatNotifications)
     * @returns {Object|null} Updated pool data
     */
    updatePool(poolId, updates) {
        if (!this.pools.has(poolId)) return null;

        const pool = this.pools.get(poolId);
        const oldPool = { ...pool };

        // Update allowed properties
        if (updates.name !== undefined) pool.name = updates.name;
        if (updates.maxDice !== undefined) pool.maxDice = Math.max(1, parseInt(updates.maxDice) || 1);
        if (updates.autoRoll !== undefined) pool.autoRoll = Boolean(updates.autoRoll);
        if (updates.chatNotifications !== undefined) pool.chatNotifications = Boolean(updates.chatNotifications);

        this._savePools();
        this._triggerEvent('poolUpdated', { poolId, oldPool, pool });
        Hooks.callAll('rnk-dedpewl-pool-updated', { poolId, oldPool, pool });

        return pool;
    }

    /**
     * Add a die to a pool
     * @param {string} poolId - Pool ID
     * @param {string} userId - User adding the die
     * @returns {boolean} Success
     */
    addDie(poolId, userId = game.user.id) {
        this._ensureInitialized();

        const pool = this.pools.get(poolId);
        if (!pool) return false;

        if (pool.dice.length >= pool.maxDice) {
            ui.notifications.warn(game.i18n.localize('RNKDEDPWL.PoolFull'));
            return false;
        }

        pool.dice.push({
            id: `die_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            userId,
            addedAt: Date.now()
        });

        this._savePools();
        this._triggerEvent('dieAdded', { poolId, pool, userId });
        Hooks.callAll('rnk-dedpewl-pool-updated', { poolId, pool, userId });

        // Send chat notification if enabled
        if (pool.chatNotifications) {
            this._sendPoolStatusUpdate(pool, 'dieAdded', { userId });
        }

        // Check if pool is now full
        if (pool.dice.length >= pool.maxDice && pool.autoRoll) {
            this.rollPool(poolId);
        }

        return true;
    }

    /**
     * Remove the last die from a pool
     * @param {string} poolId - Pool ID
     * @returns {boolean} Success
     */
    removeDie(poolId) {
        const pool = this.pools.get(poolId);
        if (!pool || pool.dice.length === 0) return false;

        const removedDie = pool.dice.pop();
        this._savePools();
        this._triggerEvent('dieRemoved', { poolId, pool, removedDie });
        Hooks.callAll('rnk-dedpewl-pool-updated', { poolId, pool, removedDie });

        // Send chat notification if enabled
        if (pool.chatNotifications) {
            this._sendPoolStatusUpdate(pool, 'dieRemoved', { removedDie });
        }

        return true;
    }

    /**
     * Clear all dice from a pool
     * @param {string} poolId - Pool ID
     */
    clearPool(poolId) {
        const pool = this.pools.get(poolId);
        if (!pool) return;

        pool.dice = [];
        this._savePools();
        this._triggerEvent('poolCleared', { poolId, pool });
        Hooks.callAll('rnk-dedpewl-pool-updated', { poolId, pool });
    }

    /**
     * Get pool data
     * @param {string} poolId - Pool ID
     * @returns {Object|null} Pool data
     */
    getPool(poolId) {
        this._ensureInitialized();
        return this.pools.get(poolId) || null;
    }

    /**
     * Get all pools
     * @returns {Array} Array of pools
     */
    getAllPools() {
        this._ensureInitialized();
        return Array.from(this.pools.values());
    }

    /**
     * Roll a pool using DiceRoller
     * @param {string} poolId - Pool ID
     */
    async rollPool(poolId) {
        const pool = this.pools.get(poolId);
        if (!pool || pool.dice.length === 0) return;

        // Lazy load DiceRoller
        const { DiceRoller } = await import('./DiceRoller.js');
        const roller = new DiceRoller();

        const results = await roller.rollPool(pool);
        this._triggerEvent('poolRolled', { poolId, pool, results });
        Hooks.callAll('rnk-dedpewl-pool-updated', { poolId, pool, results });

        // Clear pool after rolling
        this.clearPool(poolId);
    }

    /**
     * Register event listener
     * @param {string} event - Event name
     * @param {Function} callback - Callback function
     */
    on(event, callback) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, []);
        }
        this.listeners.get(event).push(callback);
    }

    /**
     * Unregister event listener
     * @param {string} event - Event name
     * @param {Function} callback - Callback function
     */
    off(event, callback) {
        const listeners = this.listeners.get(event);
        if (listeners) {
            const index = listeners.indexOf(callback);
            if (index > -1) {
                listeners.splice(index, 1);
            }
        }
    }

    /**
     * Trigger event to listeners
     * @param {string} event - Event name
     * @param {Object} data - Event data
     */
    _triggerEvent(event, data) {
        const listeners = this.listeners.get(event);
        if (listeners) {
            listeners.forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error('RNK Dedpewl™ | Event listener error:', error);
                }
            });
        }
    }

    /**
     * Save pools to settings
     */
    _savePools() {
        const poolsData = {};
        this.pools.forEach((pool, id) => {
            poolsData[id] = {
                name: pool.name,
                dice: pool.dice,
                maxDice: pool.maxDice,
                autoRoll: pool.autoRoll,
                chatNotifications: pool.chatNotifications
            };
        });
        game.settings.set('rnk-dedpewl', 'pools', poolsData);
    }

    /**
     * Send pool status update to chat
     * @param {Object} pool - Pool object
     * @param {string} action - Action type ('dieAdded', 'dieRemoved', etc.)
     * @param {Object} data - Additional data
     */
    async _sendPoolStatusUpdate(pool, action, data = {}) {
        let message = '';
        let icon = '';

        switch (action) {
            case 'dieAdded':
                const userName = game.users.get(data.userId)?.name || 'Unknown User';
                message = `${userName} added a die to "${pool.name}"`;
                icon = '➕';
                break;
            case 'dieRemoved':
                message = `Die removed from "${pool.name}"`;
                icon = '➖';
                break;
            default:
                return;
        }

        const diceCount = pool.dice.length;
        const maxDice = pool.maxDice;
        const progressBar = this._createProgressBar(diceCount, maxDice);

        const content = `
            <div class="rnk-dedpewl-chat">
                <h3>${icon} Pool Status Update</h3>
                <p><strong>${message}</strong></p>
                <div style="margin: 10px 0;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span>Dice: ${diceCount}/${maxDice}</span>
                        <span>${Math.round((diceCount / maxDice) * 100)}% full</span>
                    </div>
                    ${progressBar}
                </div>
                ${pool.autoRoll && diceCount >= maxDice ?
                    '<p style="color: #39ff14; font-weight: bold;">🎲 Auto-rolling!</p>' : ''}
            </div>
        `;

        await ChatMessage.create({
            user: game.user.id,
            content,
            type: CONST.CHAT_MESSAGE_TYPES.OTHER,
            speaker: {
                alias: 'RNK Dedpewl™'
            }
        });
    }

    /**
     * Create a progress bar HTML string
     * @param {number} current - Current value
     * @param {number} max - Maximum value
     * @returns {string} HTML progress bar
     */
    _createProgressBar(current, max) {
        const percentage = Math.min((current / max) * 100, 100);
        return `
            <div style="width: 100%; height: 8px; background: #333; border-radius: 4px; overflow: hidden;">
                <div style="width: ${percentage}%; height: 100%; background: linear-gradient(90deg, #8b0000, #dc143c); border-radius: 4px; transition: width 0.3s ease;"></div>
            </div>
        `;
    }
}
