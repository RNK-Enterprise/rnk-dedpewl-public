// RNK Dedpewl™ - Pool Templates
// © 2026 RNK Enterprises. All rights reserved.
// Save and load pool configurations as templates

import { ErrorHandler } from './ErrorHandler.js';

export class PoolTemplates {
    /**
     * Create a new template from a pool
     * @param {string} name - Template name
     * @param {Object} pool - Pool to save as template
     * @returns {string} Template ID
     */
    static createTemplate(name, pool) {
        try {
            ErrorHandler.validateRequired({ name, pool }, ['name', 'pool']);

            const templates = this._loadTemplates();
            const id = `template_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

            const template = {
                id,
                name,
                maxDice: pool.maxDice,
                autoRoll: pool.autoRoll,
                chatNotifications: pool.chatNotifications,
                createdAt: Date.now()
            };

            templates[id] = template;
            this._saveTemplates(templates);

            return id;
        } catch (error) {
            ErrorHandler.handle('PoolTemplates.createTemplate', error);
            return null;
        }
    }

    /**
     * Load a template and create a pool from it
     * @param {string} templateId - Template ID
     * @param {Function} createPoolFn - Function to create pool
     * @returns {Promise<string>} New pool ID
     */
    static async loadTemplate(templateId, createPoolFn) {
        try {
            const templates = this._loadTemplates();
            const template = templates[templateId];

            if (!template) {
                throw new Error(`Template not found: ${templateId}`);
            }

            const poolId = await createPoolFn(template.name, template.maxDice, template.autoRoll, template.chatNotifications);
            return poolId;
        } catch (error) {
            ErrorHandler.handle('PoolTemplates.loadTemplate', error);
            return null;
        }
    }

    /**
     * Get all templates
     * @returns {Array} Array of template objects
     */
    static getTemplates() {
        try {
            const templates = this._loadTemplates();
            return Object.values(templates).sort((a, b) => a.name.localeCompare(b.name));
        } catch (error) {
            ErrorHandler.handle('PoolTemplates.getTemplates', error);
            return [];
        }
    }

    /**
     * Delete a template
     * @param {string} templateId - Template ID
     */
    static deleteTemplate(templateId) {
        try {
            const templates = this._loadTemplates();
            delete templates[templateId];
            this._saveTemplates(templates);
        } catch (error) {
            ErrorHandler.handle('PoolTemplates.deleteTemplate', error);
        }
    }

    /**
     * Rename a template
     * @param {string} templateId - Template ID
     * @param {string} newName - New name
     */
    static renameTemplate(templateId, newName) {
        try {
            const templates = this._loadTemplates();
            if (templates[templateId]) {
                templates[templateId].name = newName;
                this._saveTemplates(templates);
            }
        } catch (error) {
            ErrorHandler.handle('PoolTemplates.renameTemplate', error);
        }
    }

    /**
     * Load templates from settings
     * @private
     */
    static _loadTemplates() {
        return game.settings.get('rnk-dedpewl', 'poolTemplates') || {};
    }

    /**
     * Save templates to settings
     * @private
     */
    static _saveTemplates(templates) {
        game.settings.set('rnk-dedpewl', 'poolTemplates', templates);
    }
}
