// RNK Dedpewl™ - Analytics System
// © 2026 RNK Enterprises. All rights reserved.
// Track roll statistics and pool performance

import { ErrorHandler } from './ErrorHandler.js';

export class PoolAnalytics {
    /**
     * Record a pool roll for analytics
     * @param {Object} rollData - Roll results from DiceRoller
     */
    static recordRoll(rollData) {
        try {
            ErrorHandler.validateRequired(rollData, ['poolId', 'diceCount', 'successes', 'complications']);

            const analytics = this._loadAnalytics();

            // Create entry for this pool if it doesn't exist
            if (!analytics[rollData.poolId]) {
                analytics[rollData.poolId] = {
                    poolId: rollData.poolId,
                    poolName: rollData.poolName || 'Unknown',
                    totalRolls: 0,
                    totalDiceRolled: 0,
                    totalSuccesses: 0,
                    totalComplications: 0,
                    rolls: [],
                    createdAt: Date.now()
                };
            }

            const poolAnalytics = analytics[rollData.poolId];
            poolAnalytics.totalRolls++;
            poolAnalytics.totalDiceRolled += rollData.diceCount;
            poolAnalytics.totalSuccesses += rollData.successes;
            poolAnalytics.totalComplications += rollData.complications;

            // Store individual roll data (limit to last 100 rolls per pool)
            poolAnalytics.rolls.push({
                timestamp: rollData.timestamp || Date.now(),
                diceCount: rollData.diceCount,
                successes: rollData.successes,
                complications: rollData.complications,
                successRate: (rollData.successes / rollData.diceCount) * 100,
                complicationRate: (rollData.complications / rollData.diceCount) * 100
            });

            if (poolAnalytics.rolls.length > 100) {
                poolAnalytics.rolls.shift();
            }

            this._saveAnalytics(analytics);
        } catch (error) {
            ErrorHandler.handle('PoolAnalytics.recordRoll', error, { showUser: false });
        }
    }

    /**
     * Get analytics for a pool
     * @param {string} poolId - Pool ID
     * @returns {Object|null} Analytics data
     */
    static getPoolAnalytics(poolId) {
        try {
            const analytics = this._loadAnalytics();
            const poolAnalytics = analytics[poolId];

            if (!poolAnalytics) return null;

            return {
                ...poolAnalytics,
                averageSuccessRate: this._calculateAverage(
                    poolAnalytics.rolls,
                    'successRate'
                ),
                averageComplicationRate: this._calculateAverage(
                    poolAnalytics.rolls,
                    'complicationRate'
                ),
                averageDicePerRoll: poolAnalytics.totalDiceRolled / poolAnalytics.totalRolls || 0
            };
        } catch (error) {
            ErrorHandler.handle('PoolAnalytics.getPoolAnalytics', error);
            return null;
        }
    }

    /**
     * Get all analytics
     * @returns {Array} Array of pool analytics
     */
    static getAllAnalytics() {
        try {
            const analytics = this._loadAnalytics();
            return Object.values(analytics).map(poolAnalytics => ({
                ...poolAnalytics,
                averageSuccessRate: this._calculateAverage(
                    poolAnalytics.rolls,
                    'successRate'
                ),
                averageComplicationRate: this._calculateAverage(
                    poolAnalytics.rolls,
                    'complicationRate'
                ),
                averageDicePerRoll: poolAnalytics.totalDiceRolled / poolAnalytics.totalRolls || 0
            }));
        } catch (error) {
            ErrorHandler.handle('PoolAnalytics.getAllAnalytics', error);
            return [];
        }
    }

    /**
     * Get statistics summary for all pools
     * @returns {Object} Summary statistics
     */
    static getSummary() {
        try {
            const allAnalytics = this.getAllAnalytics();

            return {
                totalPools: allAnalytics.length,
                totalRolls: allAnalytics.reduce((sum, a) => sum + a.totalRolls, 0),
                totalDiceRolled: allAnalytics.reduce((sum, a) => sum + a.totalDiceRolled, 0),
                totalSuccesses: allAnalytics.reduce((sum, a) => sum + a.totalSuccesses, 0),
                totalComplications: allAnalytics.reduce((sum, a) => sum + a.totalComplications, 0),
                overallSuccessRate: this._calculateOverallRate(allAnalytics, 'totalSuccesses'),
                overallComplicationRate: this._calculateOverallRate(allAnalytics, 'totalComplications')
            };
        } catch (error) {
            ErrorHandler.handle('PoolAnalytics.getSummary', error);
            return {};
        }
    }

    /**
     * Clear analytics for a pool
     * @param {string} poolId - Pool ID
     */
    static clearPoolAnalytics(poolId) {
        try {
            const analytics = this._loadAnalytics();
            delete analytics[poolId];
            this._saveAnalytics(analytics);
        } catch (error) {
            ErrorHandler.handle('PoolAnalytics.clearPoolAnalytics', error);
        }
    }

    /**
     * Clear all analytics
     */
    static clearAllAnalytics() {
        try {
            game.settings.set('rnk-dedpewl', 'poolAnalytics', {});
        } catch (error) {
            ErrorHandler.handle('PoolAnalytics.clearAllAnalytics', error);
        }
    }

    /**
     * Calculate average of array values
     * @private
     */
    static _calculateAverage(array, key) {
        if (!array || array.length === 0) return 0;
        const sum = array.reduce((total, item) => total + item[key], 0);
        return sum / array.length;
    }

    /**
     * Calculate overall rate across all pools
     * @private
     */
    static _calculateOverallRate(allAnalytics, key) {
        const totalKey = allAnalytics.reduce((sum, a) => sum + a[key], 0);
        const totalDice = allAnalytics.reduce((sum, a) => sum + a.totalDiceRolled, 0);
        return totalDice > 0 ? (totalKey / totalDice) * 100 : 0;
    }

    /**
     * Load analytics from settings
     * @private
     */
    static _loadAnalytics() {
        return game.settings.get('rnk-dedpewl', 'poolAnalytics') || {};
    }

    /**
     * Save analytics to settings
     * @private
     */
    static _saveAnalytics(analytics) {
        game.settings.set('rnk-dedpewl', 'poolAnalytics', analytics);
    }
}
