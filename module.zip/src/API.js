// RNK Dedpewl™ - API
// © 2026 RNK Enterprises. All rights reserved.
// External API for macros and integrations

import { PoolManager } from './PoolManager.js';

export class RNKDedpewlAPI {
    constructor() {
        this.poolManager = null;
        this._initialized = false;
    }

    /**
     * Lazy initialize API
     */
    async _ensureInitialized() {
        if (this._initialized) return;

        // Lazy load PoolManager
        if (!this.poolManager) {
            this.poolManager = new PoolManager();
        }

        // Flush any pending listeners that were registered before initialization
        if (this._pendingListeners && this._pendingListeners.length > 0) {
            for (const { event, callback } of this._pendingListeners) {
                this.poolManager.on(event, callback);
            }
            this._pendingListeners = [];
        }

        this._initialized = true;
    }

    /**
     * Create a new tension pool
     * @param {string} name - Pool name
     * @param {number} maxDice - Maximum dice
     * @param {boolean} autoRoll - Auto roll when full
     * @param {boolean} chatNotifications - Enable notifications
     * @returns {string} Pool ID
     */
    async createPool(name, maxDice = 10, autoRoll = false, chatNotifications = true) {
        await this._ensureInitialized();
        return this.poolManager.createPool(name, maxDice, autoRoll, chatNotifications);
    }

    /**
     * Delete a pool
     * @param {string} poolId - Pool ID
     */
    async deletePool(poolId) {
        await this._ensureInitialized();
        this.poolManager.deletePool(poolId);
    }

    /**
     * Add die to pool
     * @param {string} poolId - Pool ID
     * @param {string} userId - User ID (optional)
     * @returns {boolean} Success
     */
    async addDie(poolId, userId = null) {
        await this._ensureInitialized();
        return this.poolManager.addDie(poolId, userId || game.user.id);
    }

    /**
     * Remove die from pool
     * @param {string} poolId - Pool ID
     * @returns {boolean} Success
     */
    async removeDie(poolId) {
        await this._ensureInitialized();
        return this.poolManager.removeDie(poolId);
    }

    /**
     * Clear pool
     * @param {string} poolId - Pool ID
     */
    async clearPool(poolId) {
        await this._ensureInitialized();
        this.poolManager.clearPool(poolId);
    }

    /**
     * Roll pool
     * @param {string} poolId - Pool ID
     */
    async rollPool(poolId) {
        await this._ensureInitialized();
        await this.poolManager.rollPool(poolId);
    }

    /**
     * Get pool data
     * @param {string} poolId - Pool ID
     * @returns {Object|null} Pool data
     */
    async getPool(poolId) {
        await this._ensureInitialized();
        return this.poolManager.getPool(poolId);
    }

    /**
     * Get all pools
     * @returns {Array} Pools array
     */
    async getAllPools() {
        await this._ensureInitialized();
        return this.poolManager.getAllPools();
    }

    /**
     * Update pool properties
     * @param {string} poolId - Pool ID
     * @param {Object} updates - Properties to update
     * @returns {Object|null} Updated pool data
     */
    async updatePool(poolId, updates) {
        await this._ensureInitialized();
        return this.poolManager.updatePool(poolId, updates);
    }

    /**
     * Register event listener
     * @param {string} event - Event name
     * @param {Function} callback - Callback function
     */
    on(event, callback) {
        if (this.poolManager) {
            this.poolManager.on(event, callback);
        } else {
            // Store for later when initialized
            this._pendingListeners = this._pendingListeners || [];
            this._pendingListeners.push({ event, callback });
        }
    }

    /**
     * Unregister event listener
     * @param {string} event - Event name
     * @param {Function} callback - Callback function
     */
    off(event, callback) {
        if (this.poolManager) {
            this.poolManager.off(event, callback);
        }
    }

    /**
     * Get API version
     * @returns {string} Version
     */
    getVersion() {
        return '1.0.0';
    }

    /**
     * Get API documentation
     * @returns {string} Documentation
     */
    getDocumentation() {
        return `
RNK Dedpewl™ API Documentation v1.0.0
=====================================

Available Methods:
- createPool(name, maxDice, autoRoll, chatNotifications)
- deletePool(poolId)
- addDie(poolId, userId)
- removeDie(poolId)
- clearPool(poolId)
- rollPool(poolId)
- getPool(poolId)
- getAllPools()
- on(event, callback)
- off(event, callback)
- getVersion()
- getDocumentation()

Events:
- poolCreated: { pool }
- poolDeleted: { poolId, pool }
- dieAdded: { poolId, pool, userId }
- dieRemoved: { poolId, pool, removedDie }
- poolCleared: { poolId, pool }
- poolRolled: { poolId, pool, results }

Example Macro:
// Create a pool
const api = game.modules.get('rnk-dedpewl').api;
const poolId = await api.createPool('My Pool', 10, true, true);

// Add a die
await api.addDie(poolId);

// Roll when ready
await api.rollPool(poolId);
        `;
    }
}

// Global API instance
let apiInstance = null;

/**
 * Get the global API instance
 * @returns {RNKDedpewlAPI} API instance
 */
export function getAPI() {
    if (!apiInstance) {
        apiInstance = new RNKDedpewlAPI();
    }
    return apiInstance;
}