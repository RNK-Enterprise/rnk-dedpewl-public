// RNK Dedpewl™ - Macro Compendium
// © 2026 RNK Enterprises. All rights reserved.
// Pre-built macros for tension pool management

export const MACROS = [
    {
        name: "Tension Pool - Add Die",
        type: "script",
        img: "icons/svg/dice-target.svg",
        command: `
// RNK Dedpewl™ - Add Die to Pool
// © 2026 RNK Enterprises. All rights reserved.

const api = game.modules.get('rnk-dedpewl')?.api;
if (!api) {
    ui.notifications.error('RNK Dedpewl™ module not found or not active');
    return;
}

const pools = api.getAllPools();
if (pools.length === 0) {
    ui.notifications.warn('No tension pools available. Create one first!');
    return;
}

const poolOptions = pools.map(p => \`<option value="\${p.id}">\${p.name} (\${p.dice.length}/\${p.maxDice})</option>\`).join('');

const content = \`
    <form>
        <div style="margin-bottom: 10px;">
            <label style="display: block; margin-bottom: 5px; font-weight: bold;">Select Pool:</label>
            <select name="poolId" style="width: 100%; padding: 5px;">
                \${poolOptions}
            </select>
        </div>
    </form>
\`;

new Dialog({
    title: "Add Die to Pool",
    content,
    buttons: {
        add: {
            label: "Add Die",
            callback: (html) => {
                const poolId = html.find('[name="poolId"]').val();
                if (poolId) {
                    const success = api.addDie(poolId);
                    if (!success) {
                        ui.notifications.warn('Could not add die to pool');
                    }
                }
            }
        }
    },
    default: "add"
}).render(true);
`,
        scope: "global",
        author: "RNK Enterprises"
    },

    {
        name: "Tension Pool - Roll Pool",
        type: "script",
        img: "icons/svg/d20.svg",
        command: `
// RNK Dedpewl™ - Roll Tension Pool
// © 2026 RNK Enterprises. All rights reserved.

const api = game.modules.get('rnk-dedpewl')?.api;
if (!api) {
    ui.notifications.error('RNK Dedpewl™ module not found or not active');
    return;
}

const pools = api.getAllPools();
if (pools.length === 0) {
    ui.notifications.warn('No tension pools available. Create one first!');
    return;
}

const poolOptions = pools.map(p => \`<option value="\${p.id}">\${p.name} (\${p.dice.length}/\${p.maxDice})</option>\`).join('');

const content = \`
    <form>
        <div style="margin-bottom: 10px;">
            <label style="display: block; margin-bottom: 5px; font-weight: bold;">Select Pool to Roll:</label>
            <select name="poolId" style="width: 100%; padding: 5px;">
                \${poolOptions}
            </select>
        </div>
    </form>
\`;

new Dialog({
    title: "Roll Tension Pool",
    content,
    buttons: {
        roll: {
            label: "Roll Pool",
            callback: (html) => {
                const poolId = html.find('[name="poolId"]').val();
                if (poolId) {
                    api.rollPool(poolId);
                }
            }
        }
    },
    default: "roll"
}).render(true);
`,
        scope: "global",
        author: "RNK Enterprises"
    },

    {
        name: "Tension Pool - Create Pool",
        type: "script",
        img: "icons/svg/book.svg",
        command: `
// RNK Dedpewl™ - Create New Pool
// © 2026 RNK Enterprises. All rights reserved.

const api = game.modules.get('rnk-dedpewl')?.api;
if (!api) {
    ui.notifications.error('RNK Dedpewl™ module not found or not active');
    return;
}

const content = \`
    <form>
        <div style="margin-bottom: 10px;">
            <label style="display: block; margin-bottom: 5px; font-weight: bold;">Pool Name:</label>
            <input type="text" name="poolName" placeholder="Enter pool name" style="width: 100%; padding: 5px;" />
        </div>
        <div style="margin-bottom: 10px;">
            <label style="display: block; margin-bottom: 5px; font-weight: bold;">Maximum Dice:</label>
            <input type="number" name="maxDice" value="10" min="1" max="50" style="width: 100%; padding: 5px;" />
        </div>
        <div style="margin-bottom: 10px;">
            <label style="display: block; margin-bottom: 5px; font-weight: bold;">Auto Roll when Full:</label>
            <input type="checkbox" name="autoRoll" />
        </div>
        <div style="margin-bottom: 10px;">
            <label style="display: block; margin-bottom: 5px; font-weight: bold;">Chat Notifications:</label>
            <input type="checkbox" name="chatNotifications" checked />
        </div>
    </form>
\`;

new Dialog({
    title: "Create New Tension Pool",
    content,
    buttons: {
        create: {
            label: "Create Pool",
            callback: (html) => {
                const poolName = html.find('[name="poolName"]').val();
                const maxDice = parseInt(html.find('[name="maxDice"]').val()) || 10;
                const autoRoll = html.find('[name="autoRoll"]').is(':checked');
                const chatNotifications = html.find('[name="chatNotifications"]').is(':checked');

                if (poolName && poolName.trim()) {
                    const poolId = api.createPool(poolName.trim(), maxDice, autoRoll, chatNotifications);
                    ui.notifications.info(\`Created pool: \${poolName} (\${poolId})\`);
                } else {
                    ui.notifications.warn('Please enter a pool name');
                }
            }
        }
    },
    default: "create"
}).render(true);
`,
        scope: "global",
        author: "RNK Enterprises"
    },

    {
        name: "Tension Pool - Show Pools",
        type: "script",
        img: "icons/svg/eye.svg",
        command: `
// RNK Dedpewl™ - Show All Pools
// © 2026 RNK Enterprises. All rights reserved.

const api = game.modules.get('rnk-dedpewl')?.api;
if (!api) {
    ui.notifications.error('RNK Dedpewl™ module not found or not active');
    return;
}

const pools = api.getAllPools();
if (pools.length === 0) {
    ui.notifications.info('No active tension pools');
    return;
}

let content = '<div style="max-height: 400px; overflow-y: auto;">';
pools.forEach(pool => {
    const percentage = Math.round((pool.dice.length / pool.maxDice) * 100);
    content += \`
        <div style="border: 1px solid #666; padding: 10px; margin: 5px 0; border-radius: 5px;">
            <h4 style="margin: 0 0 5px 0;">\${pool.name}</h4>
            <div>Dice: \${pool.dice.length}/\${pool.maxDice} (\${percentage}%)</div>
            <div style="width: 100%; height: 8px; background: #333; border-radius: 4px; margin: 5px 0;">
                <div style="width: \${percentage}%; height: 100%; background: linear-gradient(90deg, #8b0000, #dc143c); border-radius: 4px;"></div>
            </div>
            <div style="font-size: 0.9em; color: #666;">
                Auto Roll: \${pool.autoRoll ? 'Yes' : 'No'} |
                Chat Notifications: \${pool.chatNotifications ? 'Yes' : 'No'}
            </div>
        </div>
    \`;
});
content += '</div>';

new Dialog({
    title: "Active Tension Pools",
    content,
    buttons: {
        close: {
            label: "Close"
        }
    }
}).render(true);
`,
        scope: "global",
        author: "RNK Enterprises"
    },

    {
        name: "Tension Pool - Quick Roll",
        type: "script",
        img: "icons/svg/d20-grey.svg",
        command: `
// RNK Dedpewl™ - Quick Roll (1-6 dice)
// © 2026 RNK Enterprises. All rights reserved.

const api = game.modules.get('rnk-dedpewl')?.api;
if (!api) {
    ui.notifications.error('RNK Dedpewl™ module not found or not active');
    return;
}

const content = \`
    <form>
        <div style="margin-bottom: 10px;">
            <label style="display: block; margin-bottom: 5px; font-weight: bold;">Number of Dice (1-6):</label>
            <input type="number" name="diceCount" value="1" min="1" max="6" style="width: 100%; padding: 5px;" />
        </div>
        <div style="margin-bottom: 10px;">
            <label style="display: block; margin-bottom: 5px; font-weight: bold;">Pool Name:</label>
            <input type="text" name="poolName" placeholder="Quick Roll" style="width: 100%; padding: 5px;" />
        </div>
    </form>
\`;

new Dialog({
    title: "Quick Tension Roll",
    content,
    buttons: {
        roll: {
            label: "Roll",
            callback: async (html) => {
                const diceCount = parseInt(html.find('[name="diceCount"]').val()) || 1;
                const poolName = html.find('[name="poolName"]').val() || 'Quick Roll';

                // Create temporary pool and roll it
                const poolId = await api.createPool(poolName, diceCount, false, true);

                // Add dice to the pool
                for (let i = 0; i < diceCount; i++) {
                    await api.addDie(poolId);
                }

                // Roll and clean up
                await api.rollPool(poolId);
                await api.deletePool(poolId);
            }
        }
    },
    default: "roll"
}).render(true);
`,
        scope: "global",
        author: "RNK Enterprises"
    }
];