// RNK Dedpewl™ - Pool Window
// © 2026 RNK Enterprises. All rights reserved.

const { HandlebarsApplicationMixin, ApplicationV2 } = foundry.applications.api;

export class PoolWindow extends HandlebarsApplicationMixin(ApplicationV2) {
    constructor(options = {}) {
        super(options);
        this._handlePoolUpdate = this._onPoolUpdate.bind(this);
    }

    static DEFAULT_OPTIONS = {
        id: "rnk-dedpewl-pool-window",
        classes: ["rnk-dedpewl", "rnk-window"],
        tag: "div",
        window: {
            frame: true,
            title: "RNK_DEDPEWL.WindowTitle",
            icon: "fas fa-skull-crossbones",
            resizable: true,
            minimizable: true,
            controls: [
                {
                    icon: "fas fa-cog",
                    label: "RNK_DEDPEWL.Settings",
                    action: "openSettings"
                }
            ]
        },
        position: {
            width: 450,
            height: "auto"
        }
    };

    static PARTS = {
        main: {
            template: "modules/rnk-dedpewl/templates/pool.hbs"
        }
    };

    /** @override */
    async _onRender(context, options) {
        await super._onRender(context, options);
        this._setupHookListeners();
    }

    /** @override */
    async _onClose(options) {
        await super._onClose(options);
        this._removeHookListeners();
    }

    /**
     * Set up Foundry hooks for pool updates
     */
    _setupHookListeners() {
        try {
            Hooks.on('rnk-dedpewl-pool-updated', this._handlePoolUpdate);
        } catch (err) {
            console.error('RNK Dedpewl | _setupHookListeners error:', err);
        }
    }

    /**
     * Remove hook listeners when window closes
     */
    _removeHookListeners() {
        try {
            Hooks.off('rnk-dedpewl-pool-updated', this._handlePoolUpdate);
        } catch (err) {
            console.error('RNK Dedpewl | _removeHookListeners error:', err);
        }
    }

    /**
     * Handle pool update events - re-render the window
     */
    async _onPoolUpdate(data) {
        try {
            // Debounce rapid updates
            if (this._renderTimeout) clearTimeout(this._renderTimeout);
            this._renderTimeout = setTimeout(async () => {
                await this.render();
                this._renderTimeout = null;
            }, 100);
        } catch (err) {
            console.error('RNK Dedpewl | _onPoolUpdate error:', err);
        }
    }

    /** @override */
    async _prepareContext(options) {
        try {
            const context = await super._prepareContext(options);
            const api = game.modules.get('rnk-dedpewl').api;
            const pools = api ? await api.getAllPools() : [];

            return {
                ...context,
                isGM: game.user.isGM,
                pools: pools.map(pool => {
                    const diceLength = Array.isArray(pool.dice) ? pool.dice.length : 0;
                    const maxDice = parseInt(pool.maxDice) || 6;
                    return {
                        ...pool,
                        diceCount: diceLength,
                        maxDice: maxDice,
                        dice: Array(diceLength).fill(0).map((_, i) => ({ index: i })),
                        percent: Math.min(100, Math.round((diceLength / maxDice) * 100))
                    };
                }),
                hasPools: pools.length > 0
            };
        } catch (err) {
            console.error('RNK Dedpewl | PoolWindow _prepareContext error:', err);
            throw err;
        }
    }

    /** @override */
    _onClickAction(event, target) {
        const action = target.dataset.action;
        
        if (action === 'roll') this.onRollPool(event, target);
        else if (action === 'delete') this.onDeletePool(event, target);
        else if (action === 'edit') this.onEditPool(event, target);
        else if (action === 'add-die') this.onAddDie(event, target);
        else if (action === 'create') this.onCreatePool(event, target);
        else if (action === 'openSettings') this.onOpenSettings(event, target);
        else super._onClickAction(event, target);
    }

    /**
     * Handle roll action
     */
    async onRollPool(event, target) {
        try {
            const poolId = target.closest('[data-pool-id]')?.dataset.poolId;
            if (!poolId) return;
            const api = game.modules.get('rnk-dedpewl').api;
            await api.rollPool(poolId);
        } catch (err) {
            console.error('RNK Dedpewl | onRollPool error:', err);
        }
    }

    /**
     * Handle delete action
     */
    async onDeletePool(event, target) {
        try {
            const poolId = target.closest('[data-pool-id]')?.dataset.poolId;
            if (!poolId) return;
            const pool = (await game.modules.get('rnk-dedpewl').api.getAllPools()).find(p => p.id === poolId);
            
            const confirmed = await new Promise(resolve => {
                const dialog = new ConfirmDialog({
                    title: game.i18n.localize('RNK_DEDPEWL.DeletePool'),
                    content: game.i18n.localize('RNK_DEDPEWL.ConfirmDeletePool'),
                    poolName: pool?.name || poolId,
                    onConfirm: () => resolve(true),
                    onCancel: () => resolve(false)
                });
                dialog.render(true);
            });
            
            if (confirmed) {
                const api = game.modules.get('rnk-dedpewl').api;
                await api.deletePool(poolId);
            }
        } catch (err) {
            console.error('RNK Dedpewl | onDeletePool error:', err);
        }
    }

    /**
     * Handle add die action
     */
    async onAddDie(event, target) {
        try {
            const poolId = target.closest('[data-pool-id]')?.dataset.poolId;
            if (!poolId) return;
            const api = game.modules.get('rnk-dedpewl').api;
            await api.addDie(poolId);
        } catch (err) {
            console.error('RNK Dedpewl | onAddDie error:', err);
        }
    }

    /**
     * Handle edit pool action
     */
    async onEditPool(event, target) {
        try {
            const poolId = target.closest('[data-pool-id]')?.dataset.poolId;
            if (!poolId) return;
            const api = game.modules.get('rnk-dedpewl').api;
            const pool = await api.getPool(poolId);
            if (!pool) return;

            const { EditPoolWindow } = await import('./EditPoolWindow.js');
            const app = foundry.applications.instances.get(`rnk-dedpewl-edit-pool-${poolId}`);
            if (app) {
                app.render(true, {focus: true});
            } else {
                new EditPoolWindow({ pool }).render(true);
            }
        } catch (err) {
            console.error('RNK Dedpewl | onEditPool error:', err);
        }
    }

    /**
     * Handle create pool action
     */
    async onCreatePool(event, target) {
        try {
            const api = game.modules.get('rnk-dedpewl').api;
            const name = `Pool ${ (await api.getAllPools()).length + 1 }`;
            const maxDice = game.settings.get('rnk-dedpewl', 'defaultMaxDice') || 6;
            await api.createPool(name, maxDice);
        } catch (err) {
            console.error('RNK Dedpewl | onCreatePool error:', err);
        }
    }

    /**
     * Handle open settings action
     */
    async onOpenSettings(event, target) {
        try {
            const { SettingsWindow } = await import('./SettingsWindow.js');
            const app = foundry.applications.instances.get("rnk-dedpewl-settings-window");
            if (app) app.render(true, {focus: true});
            else new SettingsWindow().render(true);
        } catch (err) {
            console.error('RNK Dedpewl | onOpenSettings error:', err);
        }
    }
}

/**
 * Themed confirmation dialog matching Crimson Blood theme
 */
class ConfirmDialog extends HandlebarsApplicationMixin(ApplicationV2) {
    constructor(data = {}) {
        super(data);
        this.onConfirm = data.onConfirm || (() => {});
        this.onCancel = data.onCancel || (() => {});
        this.poolName = data.poolName || '';
        this.content = data.content || '';
    }

    static DEFAULT_OPTIONS = {
        window: {
            frame: true,
            title: "RNK_DEDPEWL.DeletePool",
            icon: "fas fa-skull-crossbones",
            resizable: false,
            minimizable: false
        },
        position: {
            width: 400,
            height: "auto"
        },
        classes: ["rnk-dedpewl", "rnk-confirm-dialog"]
    };

    static PARTS = {
        main: {
            template: "modules/rnk-dedpewl/templates/confirm-dialog.hbs"
        }
    };

    async _prepareContext(options) {
        const context = await super._prepareContext(options);
        return {
            ...context,
            content: this.content,
            poolName: this.poolName
        };
    }

    _onClickAction(event, target) {
        const action = target.dataset.action;
        if (action === 'yes') {
            this.onConfirm();
            this.close();
        } else if (action === 'no') {
            this.onCancel();
            this.close();
        }
    }
}
