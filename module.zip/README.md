# RNK™ Dedpewl

**Advanced Tension Pool System for Foundry Virtual Tabletop v13**

![Version](https://img.shields.io/badge/version-1.0.0-blue?style=flat-square)
![Foundry](https://img.shields.io/badge/foundry-11%2B-green?style=flat-square)
![License](https://img.shields.io/badge/license-RNK%20Proprietary-red?style=flat-square)

---

## Quick Start

### Installation (Premium Content)

1. **Purchase** RNK Dedpewl through one of our supported channels:
   - [Patreon](https://www.patreon.com/RagNaroks)

2. **Activate** your content key in Foundry VTT:
   - Open **Add-on Modules** → **Premium Content**
   - Enter your content key
   - Click **Activate**

3. **Install** the module:
   - Open **Add-on Modules** → **Install Module**
   - Find "RNK Dedpewl" in your purchased content
   - Click **Install**
   - Enable in your world

4. You're ready to roll tension pools!

---

## What is RNK Dedpewl?

RNK Dedpewl™ is an advanced tension pool system designed for horror-focused tabletop games. Building on the proven tension-pool mechanics popularized by games like Blades in the Dark, Dedpewl adds:

- **Multiple Simultaneous Pools** - Track tension across different scenes/conflicts
- **Real-Time Complication Tracking** - Calculate complication likelihood automatically
- **Scene Integration** - Pool buttons appear on scene controls
- **Cinematic Notifications** - Color-coded results in chat
- **Complete API** - Full macro support for advanced users

---

## Features

### Pool Management
- Create unlimited tension pools per scene
- Customize pool names and descriptions
- Adjust maximum dice per pool (1-20)
- Real-time pool visualization
- One-click pool deletion

### Dice Rolling
- Tension-based dice rolls (all pool dice rolled at once)
- Automatic complication calculation
- Success/failure determination
- Dice result history
- Macro-friendly roll API

### Integration
- Foundry chat notifications with styled results
- Sound effects for rolls (configurable)
- Scene control buttons for quick access
- World and client-scope settings
- Full compendium macro library

### Customization
- Crimson Blood theme (included)
- Customizable complication threshold
- Safe-mode rolling (disable complications)
- Per-message roll notifications
- Full CSS customization support

### Protection
- RNK Proprietary License enforcement
- Tamper-proofing systems
- Integrity verification
- Anti-reverse-engineering protection

---

## How to Use

### Basic Pool Management

1. **Create a Pool:**
   - Click the RNK Dedpewl icon on scene controls
   - Click "+ New Pool"
   - Enter pool name (e.g., "Suspect Pool", "Evidence Pool")
   - Leave or adjust max dice (default: 6)
   - Click Create

2. **Add Dice:**
   - Click the pool panel
   - Click "+ Add" to add dice
   - Each die increases tension

3. **Roll:**
   - Click the "Roll" button
   - View results in chat
   - Results show: successes, complications, overall pool status

4. **Clear or Delete:**
   - Use in-pool controls to clear all dice
   - Delete pool to remove permanently

### Macro Examples

```javascript
// Get the API
const api = game.modules.get('rnk-dedpewl').api;

// Create a pool
await api.createPool('Investigation', 6);

// Add dice to a pool
await api.addDie('Investigation');

// Roll a specific pool
await api.rollPool('Investigation');

// Get all pools
const pools = await api.getAllPools();
console.log(pools);

// Listen for roll events
api.on('poolRolled', (poolName, result) => {
    console.log(`${poolName} rolled:`, result);
});

// Get version info
const version = api.getVersion();
console.log('RNK Dedpewl version:', version);
```

---

## Configuration

### World Settings (GM Only)

**Default Max Dice**
- Controls default maximum dice allowed per pool
- Range: 1-20
- Default: 6

**Safe Rolls**
- When enabled, pools never trigger complications
- Useful for testing or less-lethal scenarios
- Default: Off

**Show Roll Messages**
- Display chat notifications for all rolls
- When disabled, only success notifications appear
- Default: On

**Play Roll Sound**
- Player-personal audio feedback on rolls
- Only affects individual player (client-side)
- Default: On

**Show Scene Button**
- Display RNK Dedpewl button on scene controls
- Quick access to pools without dialog
- Default: On

---

## License & Support

### License

RNK Dedpewl™ is protected under the **RNK Proprietary License**.

**Key Terms:**
- ✅ Free for personal use
- ✅ Full features for all users
- ✅ Support RNK on Patreon for exclusive updates
- ❌ No redistribution without permission
- ❌ No unauthorized modification or reverse engineering

For full license terms, see [LICENSE-RNK-PROPRIETARY.md](./LICENSE-RNK-PROPRIETARY.md)

### Support & Updates

**Public (Free) Access:**
- Core Tension Pool features
- Full API and macro support
- Community support via GitHub
- Regular updates and bug fixes
- All 4 language localizations

**Patreon Supporters ($5+):**
- Early access (1 week before public)
- Exclusive development roadmap
- Direct priority support
- Impact on future features
- Special thanks in credits

**VIP/Founder Tier ($15+):**
- Beta testing access
- Direct collaboration on features
- Custom theme requests
- Exclusive Discord channel
- Advanced troubleshooting support

**Contributor Tier ($25+):**
- Full development roadmap access
- Code review participation
- Feature request priority
- Attribution in module credits
- 1-on-1 development consultation

[Support RNK on Patreon](https://www.patreon.com/RagNaroks)

---

## Documentation & Resources

- **API Reference** - See [DOCS.md](./DOCS.md) for comprehensive API documentation
- **Settings Guide** - Detailed configuration options above
- **Examples** - Macro examples in Usage section
- **Report Issues** - [GitHub Issues](https://github.com/RNK-Enterprise/rnk-dedpewl/issues)
- **Discussions** - [GitHub Discussions](https://github.com/RNK-Enterprise/rnk-dedpewl/discussions)

---

## Troubleshooting

### Pools Not Appearing

**Problem:** Pool control buttons don't show on scene controls

**Solutions:**
1. Check "Show Scene Button" setting is ON
2. Verify you have GM or Trusted Player privileges
3. Reload the world (F5)
4. Re-enable the module

### Rolls Not Working

**Problem:** Rolling fails or produces no results

**Solutions:**
1. Verify module is enabled in world
2. Check browser console for errors (F12)
3. Ensure correct pool name in macro
4. Try creating a new pool from scratch

### Macros Failing

**Problem:** Macro errors when using API

**Solutions:**
1. Verify API exists: `game.modules.get('rnk-dedpewl')`
2. Check Foundry console for error messages
3. Reload the world after re-enabling
4. Verify correct async/await usage

### Theme Issues

**Problem:** Crimson Blood theme looks wrong

**Solutions:**
1. Clear browser cache (Ctrl+Shift+Delete)
2. Check for conflicting CSS in other modules
3. Verify styles are loading (DevTools → Elements)
4. Try resetting theme in settings

---

## Changelog

### Version 1.0.0 (February 2026)

**Release:** Initial public release

**Features:**
- Multiple tension pools per scene
- Real-time complication tracking
- Dice pool rolling system
- Crimson Blood theme
- Full macro API (13 public methods)
- Comprehensive settings system
- Event system for integrations
- Anti-tampering protection
- Complete documentation

**Compatibility:**
- Foundry VTT 11+
- Verified on v13
- Modern browsers (Chrome, Firefox, Safari, Edge)
- Mobile (tablet) support

**Protection:**
- RNK Proprietary License
- Integrity verification
- Anti-reverse-engineering
- Watermarking system

---

## Roadmap (Future Versions)

- [ ] Custom theme editor
- [ ] Pool templates
- [ ] Import/export pools
- [ ] Statistics tracking
- [ ] Integration with specific systems (coming)
- [ ] Mobile app companion
- [ ] Advanced complication tables
- [ ] Voice roll notifications

---

## Contributing

RNK Dedpewl™ is a proprietary product. We welcome:

- **Bug reports** - File issues on GitHub
- **Feature requests** - Share ideas on Patreon
- **Theme submissions** - Custom CSS for inclusion

We do NOT accept:
- Code pull requests (proprietary)
- Redistributions
- Modified versions

---

## Contact & Community

- **Bug Reports:** [GitHub Issues](https://github.com/RNK-Enterprise/rnk-dedpewl/issues)
- **Feature Requests:** [Patreon Community](https://www.patreon.com/RagNaroks)
- **Discord:** [RNK Enterprise Community](https://discord.com/invite/rnk)
- **Social:** [@RNK_Enterprise](https://twitter.com/RNK_Enterprise)

---

## Credits

**RNK Dedpewl™**
- Developed by RNK Enterprises © 2026
- Inspired by Blades in the Dark tension mechanics
- Built for Foundry Virtual Tabletop

**Crimson Blood Theme**
- Design: RNK Design Team
- CSS Framework: Foundry VTT ApplicationV2

---

**RNK™ is a registered trademark of RNK Enterprises. All rights reserved.**

**Unauthorized modification, reverse engineering, or redistribution is prohibited.**

---

*Last Updated: March 2, 2026*  
*Module Version: 1.0.0*  
*Foundry Compatibility: v11-13*
