# Changelog - RNK™ Dedpewl

All notable changes to RNK Dedpewl™ will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [1.0.0] - 2026-02-18

### 🎉 Release Highlights

**RNK Dedpewl™ 1.0.0 Initial Public Release**

Complete tension pool system for Foundry VTT v13 with comprehensive API, Crimson Blood theming, and production-ready protection systems.

### ✨ Features

#### Core Functionality
- ✅ Unlimited tension pools per scene
- ✅ Configurable max dice per pool (1-20)
- ✅ Real-time tension tracking
- ✅ Dice pool rolling with success/failure calculation
- ✅ Automatic complication detection
- ✅ One-click pool operations (create, delete, roll)

#### User Interface
- ✅ Scene control buttons for quick access
- ✅ Pool management window (ApplicationV2)
- ✅ Settings configuration window
- ✅ Crimson Blood dark theme with CSS variables
- ✅ Color-coded roll results (green/red/gray)
- ✅ Responsive design (desktop + tablet)
- ✅ Smooth animations and transitions

#### API & Macro Support
- ✅ 13 public API methods
- ✅ Comprehensive event system (6 event types)
- ✅ Lazy loading for performance
- ✅ Full macro documentation included
- ✅ Example macros in compendium
- ✅ Nested access via game.modules.get()

#### Integration
- ✅ Foundry ChatMessage integration
- ✅ Native Roll system integration
- ✅ World and client-scope settings
- ✅ Full localization support (English)
- ✅ Sound effect notifications
- ✅ per-message roll notifications

#### Customization
- ✅ Pool name customization
- ✅ Maximum dice limits
- ✅ Complication threshold adjustment
- ✅ Safe-mode rolling (disable complications)
- ✅ Roll message visibility toggle
- ✅ Sound effect toggle
- ✅ Scene button visibility toggle
- ✅ Full CSS customization capability

#### Protection & Security  
- ✅ RNK Proprietary License enforcement
- ✅ Tamper-proofing systems in all core files
- ✅ Integrity verification checksums
- ✅ Anti-reverse-engineering protection
- ✅ Environment validation
- ✅ Watermark injection in DOM
- ✅ Console branding with ASCII art
- ✅ License compliance monitoring

#### Quality Assurance
- ✅ Jest test suite with jsdom environment
- ✅ V13 module manifest standards
- ✅ ApplicationV2 proper implementation
- ✅ Native DOM (no jQuery)
- ✅ ES6 module support
- ✅ Comprehensive error handling
- ✅ Production-ready code organization

#### Documentation
- ✅ Complete API documentation (DOCS.md)
- ✅ User guide with examples (README.md)
- ✅ V13 compliance verification (V13_COMPLIANCE_REVIEW.md)
- ✅ In-code comments and comments
- ✅ Example macros with documentation
- ✅ Troubleshooting guide

### 🔧 Technical Details

**Code Structure:**
- 8 core JavaScript modules
- All files ≤500 LOC (PoolManager.js at 419 LOC)
- Total production code: ~1,400 LOC
- Comprehensive comments throughout

**Foundry Compatibility:**
- Minimum Version: v11.0.0
- Verified: v13.0.0
- Compatible with: WebGL and Software renderers
- Browser Support: Chrome, Firefox, Safari, Edge (modern versions)

**Performance:**
- Lazy loading for API initialization
- Efficient DOM querying with closest()
- Optimized CSS selectors
- Minimal re-renders (only when necessary)
- Startup time: <100ms

### 🛡️ Protection Systems

Every file includes:
- DO NOT MODIFY warnings
- Integrity verification (_rnk_integrity_check)
- Anti-tampering detection (_rnk_anti_tamper)
- Watermark injection (_rnk_inject_watermark)
- Environment validation loops
- Graceful degradation (window.RNK_DEDPEWL_DISABLED flag)

**License Enforcement:**
- RNK Proprietary License integration
- Trademark protection enforcement
- Unauthorized modification detection
- Audit-ready logging systems

### 📦 Package Contents

**Source Files:**
```
src/
├── init.js              (Module initialization and settings)
├── API.js              (Public API with protection)
├── DiceRoller.js       (Rolling mechanics and events)
├── PoolData.js         (Data structures)
├── PoolManager.js      (Pool management logic)
├── PoolWindow.js       (Main UI window - ApplicationV2)
├── SettingsWindow.js   (Settings UI - ApplicationV2)
└── macros.js           (Macro integration)
```

**Styling:**
```
styles/
└── main.css            (Crimson Blood theme)
```

**Templates:**
```
templates/
├── pool-window.hbs     (Main pool window)
├── settings-window.hbs (Settings dialog)
└── pool-item.hbs       (Individual pool display)
```

**Localization:**
```
languages/
└── en.json             (English - 50+ keys)
```

**Compendiums:**
```
packs/
└── macros.db           (Example macros)
```

**Documentation:**
```
README.md               (User guide)
DOCS.md                 (API reference)
V13_COMPLIANCE_REVIEW.md (Technical verification)
CHANGELOG.md            (This file)
LICENSE-RNK-PROPRIETARY.md (License terms)
```

### 🔐 Licensing

- **License:** RNK Proprietary License v1.0
- **Status:** Proprietary (not open source)
- **Free Tier:** Core tension pool features
- **Patreon Tier:** Additional features and priority support
- **Restrictions:** No redistribution, modification, or reverse engineering without permission

### 📝 Documentation Additions

Version 1.0.0 release includes:
- ✅ User guide (README.md)
- ✅ API documentation (DOCS.md)
- ✅ V13 compliance review (V13_COMPLIANCE_REVIEW.md)
- ✅ Inline code comments
- ✅ Example macros with documentation
- ✅ This changelog

### 🐛 Known Issues

No known issues at release. Please report any problems via:
- GitHub Issues: https://github.com/RNK-Enterprise/rnk-dedpewl/issues
- Patreon: https://www.patreon.com/RagNaroks

### ⚠️ Breaking Changes

N/A - Initial release

### 🙏 Credits

**Development:** RNK Enterprises © 2026  
**Framework:** Foundry Virtual Tabletop  
**Theme Inspiration:** Blades in the Dark  
**Community:** Thanks to early testers and feedback providers

### 🔄 Roadmap

**Planned for Future Releases:**
- [ ] Custom theme editor
- [ ] Pool templates
- [ ] Statistics tracking
- [ ] Import/export functionality
- [ ] Additional localization (FR, DE, ES, etc.)
- [ ] Integration with specific game systems
- [ ] Mobile app companion
- [ ] Voice notifications
- [ ] Advanced complication triggers

---

## [Unreleased]

### Planned Features

These features are under development and planned for upcoming releases:

#### v1.1.0 (Q2 2026)
- Theme editor for custom color schemes
- Pool templates for quick setup
- Statistics tracking per pool
- Export pools as JSON

#### v1.2.0 (Q3 2026)
- System-specific integrations (D&D 5e, PF2e, etc.)
- Advanced complication tables
- Macro library expansion
- Localization additions (French, German, Spanish)

#### v2.0.0 (Q4 2026)
- Mobile app companion
- Voice-based roll notifications
- Integration with campaign journals
- Cloud sync for multi-device support

### Call for Feedback

We welcome feature requests on Patreon or GitHub to help shape the roadmap!

---

## Version History Summary

| Version | Date | Status | Purpose |
|---------|------|--------|---------|
| 1.0.0 | 2026-02-18 | ✅ Released | Initial public release |

---

## How to Update

### From Earlier Versions
N/A - Initial release

### To Future Versions
RNK Dedpewl supports automatic updates via Foundry's module browser:

1. Foundry will notify you when updates are available
2. Click "Update" in the module browser
3. Module will back up before updating
4. No user configuration is lost in updates

### Manual Update
If automatic update doesn't work:

1. Note your current settings (`game.settings`)
2. Uninstall the module
3. Install the latest version
4. Re-enable in world

---

## Support

### Getting Help

- **Documentation:** See README.md and DOCS.md
- **API Questions:** See DOCS.md API reference
- **Bug Reports:** GitHub Issues
- **Feature Requests:** Patreon or Discord
- **Installation Help:** Community Discord

### Reporting Issues

When reporting bugs, please include:
- Foundry version
- Module version
- Steps to reproduce
- Actual vs expected behavior
- Browser console errors (F12)

**Report to:**
- https://github.com/RNK-Enterprise/rnk-dedpewl/issues
- https://www.patreon.com/RagNaroks (DM)
- Discord: [RNK Community](https://discord.com/invite/rnk)

---

## License

RNK Dedpewl™ © 2026 RNK Enterprises  
All rights reserved under RNK Proprietary License

For full license terms, see [LICENSE-RNK-PROPRIETARY.md](./LICENSE-RNK-PROPRIETARY.md)

---

## Acknowledgments

Special thanks to:
- Foundry VTT for the amazing platform
- The community for feedback and support
- Early testers who helped refine the system
- RNK Enterprises for vision and resources

---

**RNK™ is a registered trademark of RNK Enterprises. All rights reserved.**

*Last Updated: February 18, 2026*  
*Module Version: 1.0.0*  
*Foundry Compatibility: v11-13*
